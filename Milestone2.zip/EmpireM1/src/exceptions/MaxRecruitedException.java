package exceptions;

@SuppressWarnings("serial")
public class MaxRecruitedException extends BuildingException {

	public MaxRecruitedException() {

	}

	public MaxRecruitedException(String s) {
		super(s);

	}

}

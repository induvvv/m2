package exceptions;

@SuppressWarnings("serial")
public class FriendlyFireException extends ArmyException {

	public FriendlyFireException() {

	}

	public FriendlyFireException(String s) {
		super(s);

	}

}
